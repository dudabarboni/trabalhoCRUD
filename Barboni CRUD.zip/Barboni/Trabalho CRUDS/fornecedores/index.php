<?php require_once "consultar_todos.php"; ?>
<?php require_once "../template/cabecalho.php"; ?>
<?php require_once "../template/menu.php"; ?>



  
    <div class="counteiner">
        <h1>Fornecedores</h1>
        <hr>
    </div>

    <div class="text-end">
        <a href="form.php" class="btn btn-success">Inserir Fornecedores <i class="fa-solid fa-plus"></i></a>
    </div>

    <table class="table" id ="#myTable">
  <thead>
    <tr>
      <th scope="col">Nome</th>
      <th scope="col">CNPJ</th>
      <th scope="col">E-mail</th>
      <th scope="col">Telefone</th>
      
    </tr>
  </thead>
  <tbody>

  <?php foreach($fornecedores as $fornecedor){?>
    <tr>
      <th><?php echo $fornecedor['nome']; ?></th>
      <td><?php echo $fornecedor['cnpj']; ?></td>
      <td><?php echo $fornecedor['email']; ?></td>
      <td><?php echo $fornecedor['telefone']; ?></td>
      
      
      <td>
        <td class="text-end">
        <a href="excluir.php?id=<?php echo $fornecedor['id']; ?>" class="btn btn-danger"><i class="fa-solid fa-trash-can"></i>  Excluir</a>
        <a href="form.php?id=<?php echo $fornecedor['id']; ?>" class="btn btn-primary"><i class="fa-solid fa-pen-to-square"></i>  Atualizar</a>
      </td>
      </td>
    </tr>
    <?php }?>
    
    

  </tbody>
</table>

<?php require_once "../template/rodape.php"; ?>
    