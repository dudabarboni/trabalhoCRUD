<?php require_once "consultar_por_id.php" ?>
<?php require_once "../template/cabecalho.php"; ?>

    <div class="container">

    <h1>Cadastro de Fornecedores</h1>
    <hr>
    
    <form 
    action="<?php echo isset($fornecedor) ? 'atualizar.php' : 'inserir.php' ?>" 
    method="post"
    enctype="multipart/form-data"
    >

    
    <input type="hidden" name="id" id="id" value="<?php echo $fornecedor['id'] ??""; ?>">

    <label for="nome" class="form-label">Nome</label><br>
    <input class="form-control" type="text" name="nome" id="nome" value="<?php echo $fornecedor['nome'] ??""; ?>"><br>
   
    
    <label for="cnpj" class="form-label">CNPJ</label><br>
    <input class="form-control" type='text' name="cnpj" id="cnpj" value="<?php echo $fornecedor['cnpj'] ?? ""; ?>"><br>

    <label for="email" class="form-label">E-mail</label><br>
    <input class="form-control" type="email" name="email" id="email" value="<?php echo $fornecedor['email'] ?? ""; ?>"><br>

    <label for="telefone" class="form-label">Telefone</label><br>
    <input class="form-control" type="text" name="telefone" id="telefone" value="<?php echo $fornecedor['telefone'] ?? ""; ?>"><br>


    <button type="submit" class="btn btn-dark">Cadastrar</button><br>


    </form>
</div>

    <?php require_once "../template/rodape.php"; ?>