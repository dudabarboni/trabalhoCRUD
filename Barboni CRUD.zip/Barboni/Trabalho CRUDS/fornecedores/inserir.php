<?php

    require_once "../conexao.php";


    $nome = $_POST["nome"];
    $cnpj = $_POST["cnpj"];
    $email = $_POST["email"];
    $telefone = $_POST["telefone"];
 

    //string com o comenado sql para ser executado o BD
    $sql = "INSERT INTO `fornecedores` ( `nome`, `cnpj`, `email`, `telefone`) 
    VALUES (?, ?, ?, ?);";
    echo $sql;

    //prepara o sql para ser executado no banco de dados
   $comando = $conexao->prepare($sql);
 
   //adiciona valores nos parametros
    $comando->bind_param("ssss", $nome, $cnpj, $email, $telefone);

   //executa o sql - comando do banco de dados
   $comando->execute();
   //abre o arquivo form.php
   header("location: index.php");
 