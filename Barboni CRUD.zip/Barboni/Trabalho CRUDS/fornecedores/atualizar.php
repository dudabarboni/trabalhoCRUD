<?php

    require_once "../conexao.php";

    $id = $_POST['id'];
    $nome = $_POST["nome"];
    $cnpj = $_POST["cnpj"];
    $email = $_POST["email"];
    $telefone = $_POST["telefone"];

    //string com o comenado sql para ser executado o BD
    $sql = "UPDATE fornecedores SET `nome`= ?, `cnpj`= ?, `email`= ?, `telefone`= ? WHERE `id`= ?;";
    

    //prepara o sql para ser executado no banco de dados
   $comando = $conexao->prepare($sql);
 
   //adiciona valores nos parametros
    $comando->bind_param("ssssi", $nome, $cnpj, $email, $telefone, $id);

   //executa o sql - comando do banco de dados
   $comando->execute();
   //abre o arquivo form.php
   header("location: index.php");

   
 